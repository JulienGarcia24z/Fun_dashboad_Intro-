source("library.R")
source("code/graphjulien.R")

# DASHBOARD
dash = dashboardPage(
  skin = "purple",
  dashboardHeader(title = "Python pour tous"),
  dashboardSidebar(),
  dashboardBody(
   
  # InfoBox ------------------------------------------------
    fluidRow(
      infoBox("1", 10 * 3, icon = icon("comment"), fill = TRUE, color = "green"),
      infoBox("Nombre d'utilisateurs", 10 * 4, icon = icon("users"), fill = TRUE, color = "orange"),
      infoBox("3", 10 * 3, icon = icon("envelope-o"), fill = TRUE, color = "fuchsia"),
      ),
    
    fluidRow(
 #  Graphique ------------------------------------------------
    box(title="Titre1", plotOutput("plot1")),
    box(title="Titre2", plotOutput("plot2")),
    box(title="Titre3", plotOutput("plot3")),
    box(title="Titre4", plotOutput("plot4"))
    ),
  # CSS ------------------------------------------------
  tags$head(
     tags$link(rel = "stylesheet", type = "text/css", href = "custom.css")
    )  
  
  )
  
)

# SERVER
server = function(input, output) {
  output$plot1 = renderPlot(graph2)
}
# Run dashboard 
shinyApp(dash, server)